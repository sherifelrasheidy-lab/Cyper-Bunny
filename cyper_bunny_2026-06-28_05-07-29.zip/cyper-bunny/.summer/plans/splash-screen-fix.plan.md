---
name: splash-screen-fix
overview: >-
  Rewrite boot_sequence.gd to match the actual SplashScreenCanvas scene
  structure with Tween-based animations, glitch effects, and queue_free handoff
createdAt: '2026-06-28T01:04:41.597Z'
todos:
  - id: rewrite-boot-script
    content: >-
      Rewrite boot_sequence.gd to reference SplashScreenCanvas nodes, add
      signal, use Tweens for fade animations, scale bounce, glitch bursts, and
      queue_free on completion
    status: pending
  - id: verify-run
    content: Run and verify the splash sequence compiles and renders correctly
    status: pending
---
## Scene structure (already built)
- Main (Node2D) → boot_sequence.gd
  - SplashScreenCanvas (CanvasLayer, layer 10)
    - SplashContainer (Control, full screen, mouse_filter=STOP)
      - BackgroundMask (ColorRect, #111116)
      - LogoViewport (TextureRect, centered, logo texture)
      - GlitchRect (ColorRect, full screen, ShaderMaterial with SCREEN_TEXTURE glitch shader)
  - MenuLayer (CanvasLayer, layer 5, initially hidden)
    - MenuParticles, MenuTitle, MenuSubtitle, VersionLabel

## Script changes
- Add `signal splash_sequence_complete`
- Replace BootLayer refs with SplashScreenCanvas refs
- Replace LogoLabel with LogoViewport (TextureRect)
- Use create_tween() for fade-in (alpha + scale bounce) and fade-out
- Glitch bursts during HOLD phase via _process
- queue_free SplashScreenCanvas on fade-out tween.finished
- Emit splash_sequence_complete signal before queue_free

## Verification
- runAndVerify to confirm no errors
- visualCheck to confirm logo renders
