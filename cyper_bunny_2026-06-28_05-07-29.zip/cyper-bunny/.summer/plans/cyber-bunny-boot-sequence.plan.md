---
name: cyber-bunny-boot-sequence
overview: >-
  Dark cyberpunk splash boot sequence with logo fade-in, glitch effects, hold,
  fade-out, and particle-emitting main menu
createdAt: '2026-06-28T00:56:57.011Z'
todos:
  - id: main-scene
    content: >-
      Create main.tscn with dark canvas, boot sequence controller, and particle
      background
    status: completed
  - id: boot-logic
    content: >-
      Write boot_sequence.gd: multi-phase state machine (fade-in, hold, glitch,
      fade-out, menu-handoff)
    status: completed
  - id: glitch-effects
    content: Add glitch shader and randomized glitch bursts during logo display
    status: completed
  - id: particle-menu
    content: Build particle-emitting main menu screen that appears after boot handoff
    status: completed
  - id: input-map
    content: Bind input actions and set main_scene in project settings
    status: completed
  - id: run-verify
    content: 'runAndVerify: confirm boot sequence compiles and renders correctly'
    status: in_progress
---
## Scene structure
- **main.tscn** (2D): Node2D root
  - `Background`: ColorRect (dark charcoal #1a1a1a)
  - `ParticleLayer`: Node2D with CPUParticles2D nodes for ambient particle field
  - `BootSequence`: CanvasLayer
    - `LogoContainer`: CenterContainer with Label ("CYBER BUNNY") 
    - `GlitchOverlay`: ColorRect (transient glitch bars)
    - `ProgressIndicator`: small loading bar or dots
  - `MainMenu`: CanvasLayer (initially hidden)
    - Title, menu buttons, particle effects behind

## Boot phases
1. **INIT**: Black screen, short delay (0.3s)
2. **FADE_IN**: Logo fades in over 1.0s via modulate alpha tween
3. **HOLD**: Logo held at full opacity for 2.5s with occasional glitch bursts
4. **FADE_OUT**: Logo fades out over 0.8s
5. **MENU**: Boot layer hides, main menu appears with particles

## Glitch effect
- ShaderMaterial on a full-screen ColorRect
- Random horizontal slice displacement + RGB shift
- Triggered at random intervals during HOLD phase (3-5 bursts)

## Particle menu
- CPUParticles2D emitting tech-styled particles (small squares/dots)
- Dark palette: deep purples, cyan, white accents
- Slow drift upward, fading out

## Decisions
- 2D project (splash screens/UI are inherently 2D)
- GDScript (default for new projects, tight Godot integration)
- No external assets needed yet - all programmatic (rects, labels, particles, shaders)
