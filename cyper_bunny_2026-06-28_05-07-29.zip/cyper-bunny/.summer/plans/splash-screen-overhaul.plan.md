---
name: splash-screen-overhaul
overview: >-
  Replace text-based boot sequence with logo-image splash screen using Tween
  animations and CanvasLayer architecture
createdAt: '2026-06-28T01:02:19.136Z'
todos:
  - id: generate-logo
    content: Generate a dark cyberpunk Cyber Bunny logo image for the splash screen
    status: completed
  - id: import-logo
    content: Import the generated logo image into the project
    status: completed
  - id: rewrite-scene
    content: Rewrite main.tscn with SplashScreenCanvas layer + TextureRect for logo
    status: completed
  - id: rewrite-script
    content: >-
      Rewrite boot_sequence.gd with Tween-based fade-in/hold/fade-out lifecycle
      and splash_sequence_complete signal
    status: completed
  - id: verify-boot
    content: runAndVerify to confirm splash renders and transitions cleanly
    status: completed
---
## Scene Hierarchy

SplashScreenCanvas (CanvasLayer, layer=10)
  SplashContainer (Control, full-rect anchors)
    BackgroundMask (ColorRect, #111116)
    LogoViewport (TextureRect, center anchors, keep aspect, logo texture)

## Boot Timeline

- Phase 1 (0.0-0.5s): Input blocked, logo alpha at 0
- Phase 2 (0.5-1.5s): Tween fade-in alpha 0->1 with ease-out quad, optional scale bounce
- Phase 3 (1.5-3.5s): Static hold at full opacity
- Phase 4 (3.5-4.5s): Tween fade-out, then queue_free + splash_sequence_complete signal

## Signal Handoff

After queue_free, fire splash_sequence_complete. Connect to existing MenuLayer reveal logic.
