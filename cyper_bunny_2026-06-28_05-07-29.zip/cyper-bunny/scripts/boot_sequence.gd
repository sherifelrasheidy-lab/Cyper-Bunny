extends Node2D

## Fired when the splash screen has been fully cleaned up.
## Connect this to your profile check / menu logic.
signal splash_sequence_complete

@onready var splash_canvas: CanvasLayer = $SplashScreenCanvas
@onready var background_mask: ColorRect = $SplashScreenCanvas/SplashContainer/BackgroundMask
@onready var logo_viewport: TextureRect = $SplashScreenCanvas/SplashContainer/LogoViewport
@onready var glitch_rect: ColorRect = $SplashScreenCanvas/SplashContainer/GlitchRect
@onready var menu_layer: CanvasLayer = $MenuLayer


func _ready() -> void:
	# --- Phase 1: Absolute Initialization (0.0s - 0.5s) ---
	# Block all input by disabling processing on the root until the splash finishes.
	set_process_input(false)

	# Start completely invisible.
	logo_viewport.modulate.a = 0.0
	background_mask.modulate.a = 1.0
	menu_layer.visible = false

	# Reset glitch shader parameters.
	glitch_rect.visible = false
	if glitch_rect.material is ShaderMaterial:
		glitch_rect.material.set_shader_parameter("intensity", 0.0)
		glitch_rect.material.set_shader_parameter("rgb_shift", 0.0)

	# Brief pause so the player sees a dark screen first (the system "booting" feel).
	await get_tree().create_timer(0.5).timeout
	_start_fade_in()


# --- Phase 2: Fade-In Sequence (0.5s - 1.5s) ---
func _start_fade_in() -> void:
	var tween := create_tween().set_parallel(true)

	# Alpha fade-in with ease-out quad.
	tween.tween_property(
		logo_viewport, "modulate:a",
		1.0, 1.0
	).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)

	# Subtle scale bounce for a "system coming online" feel.
	tween.tween_property(
		logo_viewport, "scale",
		Vector2(1.04, 1.04), 0.45
	).set_ease(Tween.EASE_OUT)
	tween.tween_property(
		logo_viewport, "scale",
		Vector2(1.0, 1.0), 0.55
	).set_ease(Tween.EASE_IN).set_delay(0.45)

	# Glitch artifact flash mid-way through the fade-in.
	_trigger_glitch_burst()

	await tween.finished

	# --- Phase 3: High-Impact Hold (1.5s - 3.5s) ---
	logo_viewport.modulate.a = 1.0
	await get_tree().create_timer(2.0).timeout

	# --- Phase 4: Fade-Out & Handoff (3.5s - 4.5s) ---
	_start_fade_out()


func _start_fade_out() -> void:
	var tween := create_tween().set_parallel(true)

	# Fade the entire container out.
	tween.tween_property(
		background_mask, "modulate:a",
		0.0, 1.0
	).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tween.tween_property(
		logo_viewport, "modulate:a",
		0.0, 1.0
	).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)

	await tween.finished

	# --- Cleanup & Handoff ---
	splash_canvas.queue_free()
	splash_sequence_complete.emit()

	_show_menu()


func _show_menu() -> void:
	menu_layer.visible = true
	# Re-enable input processing now that the splash is gone.
	set_process_input(true)

	var menu_particles: CPUParticles2D = $MenuLayer/MenuParticles
	menu_particles.emitting = true


# --- Glitch Effect ---
func _trigger_glitch_burst() -> void:
	if not glitch_rect.material is ShaderMaterial:
		return

	glitch_rect.visible = true
	var mat: ShaderMaterial = glitch_rect.material
	mat.set_shader_parameter("intensity", randf_range(0.2, 0.5))
	mat.set_shader_parameter("rgb_shift", randf_range(1.0, 4.0))
	mat.set_shader_parameter("slice_pos", randf_range(0.15, 0.8))
	mat.set_shader_parameter("slice_height", randf_range(0.02, 0.08))

	await get_tree().create_timer(0.08).timeout

	glitch_rect.visible = false
	mat.set_shader_parameter("intensity", 0.0)
	mat.set_shader_parameter("rgb_shift", 0.0)
